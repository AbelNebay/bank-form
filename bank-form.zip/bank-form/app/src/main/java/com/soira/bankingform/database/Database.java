package com.soira.bankingform.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * The below database helper is used to store the given path according to their newly added one!
 * &amp; setting_layout bit more_dark.... PEACE!
 */
public class Database extends SQLiteOpenHelper {
    public static final String NATIONAL_ID = "NATIONAL_ID";
    public static final String DATA = "DATA";
    private static final String BANKING_TABLE = "BANKING_TABLE";
    private static final String DATABASE_NAME = "BANKING_FORM.db";
    private final String TABLE_NAME;

    /**
     * mn constructor with
     *
     * @param context Author       : Abel Nebay
     *                College      : Mai-Nefhi College of Science
     *                Department   : Applied Biology IV Year
     *                E-mail       : abelnebay555@gmail.com
     *                Website      : https://www.leafpedia.com
     *                Company      : Leaf Pedia, Inc.
     *                Foundation   : SoiraPlayer, Inc.
     *                Tel          : +291-7276-749
     *                Year         : 2023 - Tesseney, Asmara - Eritrea, Norther East Africa @Earth {#3 Planet}
     */
    Database(Context context, String TABLE_NAME) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = TABLE_NAME;
    }

    public Database(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = BANKING_TABLE;
    }

    /**
     * onCreate for creating the existing or new table by the name
     */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + NATIONAL_ID + " TEXT PRIMARY KEY, " + DATA + " TEXT)");

    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public Cursor getAllData() {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME, null);
    }

    @Nullable
    public String getValueAt(String id) {
        Cursor cursor = getDataAt(id);
        String value = null;
        if (cursor != null && cursor.moveToFirst()) {
            value = cursor.getString(cursor.getColumnIndex(NATIONAL_ID));
            cursor.close();
        }
        return value;
    }

    public boolean updateWhole(String id, String data) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATA, data);
        int result = database.update(TABLE_NAME, contentValues, NATIONAL_ID + "=?", new String[]{id});
        database.close();
        return result > 0;
    }

    public Cursor getDataAt(String media_id) {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME + " where " + NATIONAL_ID + " ='" + media_id + "'", null);
    }

    public boolean insertData(String id, String data) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NATIONAL_ID, id);
        contentValues.put(DATA, data);
        long result = database.insert(TABLE_NAME, null, contentValues);
        database.close();
        return result != -1;
    }

    public boolean deleteData(String media_id) {
        SQLiteDatabase database = this.getWritableDatabase();
        int i = database.delete(TABLE_NAME, NATIONAL_ID + "=?", new String[]{media_id});
        database.close();
        return i > 0;
    }
}
