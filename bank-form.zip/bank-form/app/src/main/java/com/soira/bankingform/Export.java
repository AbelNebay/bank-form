package com.soira.bankingform;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.soira.bankingform.database.Database;
import com.soira.bankingform.tool.Data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;

public class Export extends AppCompatActivity {

    Button downloadBtn;
    RelativeLayout waiting;
    String location = "storage/emulated/0/DATABASE";
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.export);

        sharedPreferences = getSharedPreferences("SETTING", MODE_PRIVATE);
        downloadBtn = (Button) findViewById(R.id.downloadBtn);
        waiting = (RelativeLayout) findViewById(R.id.waiting);

        // Request permission (only required for Android 6.0+)
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

        File path = new File(location);
        if (!path.exists()) {
            if (!path.mkdirs()) {
                location = "storage/emulated/0";
            }
        }

        downloadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean result = false;
                File file = new File(location);
                if (file != null & file.listFiles() != null) {
                    for (File entry : file.listFiles()) {
                        if (entry.getName().endsWith(".bank")) {
                            entry.delete();
                        }
                    }
                }
                try {
                    String HEADERS = "";
                    for (String entry : Data.ACTUALS) {
                        HEADERS += entry.replace(",", "") + ",";
                    }
                    HEADERS = HEADERS.substring(0, HEADERS.length() - 1);
                    String FINAL = HEADERS + "\n";

                    Cursor video_cursor = new Database(Export.this).getAllData();
                    if (video_cursor != null && video_cursor.getCount() > 0 && video_cursor.moveToFirst()) {
                        do {
                            String data = video_cursor.getString(video_cursor.getColumnIndex(Database.DATA));
                            FINAL += data.replace(",", "").replace("@", ",") + "\n";
                        } while (video_cursor.moveToNext());
                        video_cursor.close();
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Export.this);
                        builder.setTitle("Export information");
                        builder.setMessage("Your database is empty.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }

                    FINAL = root.enc(FINAL);
                    String two = sharedPreferences.getString("two", "");
                    String three = sharedPreferences.getString("three", "");
                    BufferedWriter fos = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(location + File.separator +
                            two + "-" + three + "-" + DateFormat.format("yyyy-MM-dd HH-mm",
                            new Date()) + ".bank")));
                    fos.write(FINAL);
                    fos.close();
                    result = true;
                } catch (Exception e) {
                    ActivityCompat.requestPermissions(Export.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                }

                String message = result ? "Database successfully exported to Internal storage." : "Export failed. Check if:\n" +
                        "\n" +
                        "1. Storage permission is granted.\n" +
                        "\n" +
                        "2. Enough storage space is available.";
                AlertDialog.Builder builder = new AlertDialog.Builder(Export.this);
                builder.setTitle("Export information");
                builder.setMessage(message);
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }
}