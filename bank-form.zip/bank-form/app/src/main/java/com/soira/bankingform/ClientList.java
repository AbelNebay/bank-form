package com.soira.bankingform;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.soira.bankingform.adapter.UserAdapter;
import com.soira.bankingform.database.Database;

import java.util.ArrayList;
import java.util.List;

public class ClientList extends AppCompatActivity {

    Spinner spinner;
    TextView fetch_info;
    SharedPreferences sharedPreferences;
    AlertDialog dialog;
    private ListView userList;
    private EditText searchInput;
    private Button btnSearch;
    private List<String> users = new ArrayList<>();
    private UserAdapter adapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.client_list);
        sharedPreferences = getSharedPreferences("SETTING", MODE_PRIVATE);
        userList = (ListView) findViewById(R.id.userList);
        searchInput = (EditText) findViewById(R.id.searchInput);
        fetch_info = (TextView) findViewById(R.id.fetch_info);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        spinner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> spinner_adapter = ArrayAdapter.createFromResource(this,
                R.array.columns_spinner, android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(spinner_adapter);

        adapter = new UserAdapter(this, users, new UserAdapter.OnDeleteClickListener() {
            public void onDelete(String userId) {
                deleteUser(userId);
            }

            @Override
            public void onClicked(String user) {
                Register.USERS = user;
                Intent intent = new Intent(ClientList.this, Register.class);
                startActivity(intent);
            }
        });
        userList.setAdapter(adapter);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String keyword = searchInput.getText().toString();
                fetchUsers(keyword);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchUsers("");

    }

    private void fetchUsers(String keyword) {
        keyword = keyword.toLowerCase();
        users.clear();
        adapter.clear();

        Cursor video_cursor = new Database(this).getAllData();
        if (video_cursor != null && video_cursor.getCount() > 0 && video_cursor.moveToFirst()) {
            do {
                String data = video_cursor.getString(video_cursor.getColumnIndex(Database.DATA));
                int index = spinner.getSelectedItemPosition();
                String key = data.split("@")[index].toLowerCase();
                if (key.contains(keyword)) {
                    users.add(data);
                }
            } while (video_cursor.moveToNext());
            video_cursor.close();
        }

        int size = users.size();
        String message = size == 1 ? "client found." : "clients found.";
        fetch_info.setText(String.valueOf(size) + " " + message);
        adapter.notifyDataSetChanged();
    }

    private void deleteUser(String userId) {
        Database database = new Database(this);
        boolean deleted = database.deleteData(userId);
        if (deleted) {
//            new AlertDialog.Builder(ClientList.this)
//                    .setTitle("Delete Successfully")
//                    .setMessage("Successfully deleted.")
//                    .setPositiveButton("OK", null)
//                    .show();
            fetchUsers("");
        } else {
            new AlertDialog.Builder(ClientList.this)
                    .setTitle("Delete Error")
                    .setMessage("Deleting failed.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }
}