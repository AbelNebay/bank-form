package com.soira.bankingform;

import java.util.ArrayList;
import java.util.Arrays;

public class root {

    private static final ArrayList<String> ALPHA_CORRECT = new ArrayList();
    private static final ArrayList<String> ALPHA_STRONG = new ArrayList();

    static {
        String[] caps_ext = new String[]{
                "@", "-", "\"", ";", "?", "\'", "!", "$", "&", "*", "(", ")", "[", "]", "=", "-", "+", "/", ".", ",", "%", "^", "~", "`",
                " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        ALPHA_CORRECT.addAll(Arrays.asList(caps_ext));

        String[] caps_ext2 = new String[]{
                "@", "-", "!", "(", ")", "[", "]", "=", "-", "+", ",", "%",
                " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};


        ALPHA_STRONG.addAll(Arrays.asList(caps_ext2));
    }

    public static String qar(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qaq(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    public static String qaldecremental(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qaladditive(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qal(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static boolean isAlphaStrong(String input) {
        if (input.isEmpty()) {
            return true;
        }
        for (char entry : input.toCharArray()) {
            if (!ALPHA_STRONG.contains(String.valueOf(entry))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isAlpha(String input) {
        if (input.isEmpty()) {
            return true;
        }
        for (char entry : input.toCharArray()) {
            if (!ALPHA_CORRECT.contains(String.valueOf(entry))) {
                return false;
            }
        }
        return true;
    }

    public static String qal2(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            String va = String.valueOf((char) (roll + 10));
            if (!isAlpha(va)) {
                va = "-";
            }
            b += va;
        }

        return b;
    }

    public static String dec(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    public static String a2(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 10));
        }

        return b;
    }

    public static String enc(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qaw(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    public static String qah(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qao(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    public static String qaz(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qax(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    public static String qay(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }

        return b;
    }

    public static String qaa(String a) {
        if (a == null) {
            return null;
        }
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

}
