package com.soira.bankingform.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.soira.bankingform.R;

import java.util.List;

public class UserAdapter extends ArrayAdapter<String> {
    private Context context;
    private List<String> users;
    private OnDeleteClickListener listener;

    public UserAdapter(Context context, List<String> users, OnDeleteClickListener listener) {
        super(context, 0, users);
        this.context = context;
        this.users = users;
        this.listener = listener;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        final String user = users.get(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.row_item, parent, false);
        }

        final TextView username = (TextView) convertView.findViewById(R.id.username);
        Button btnDelete = (Button) convertView.findViewById(R.id.btnDelete);
        LinearLayout holder = (LinearLayout) convertView.findViewById(R.id.holder);
        holder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClicked(user);
            }
        });
        username.setText(user.split("@")[0] + " => " + user.split("@")[9]);


        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(context)
                        .setTitle("Confirm Deletion")
                        .setMessage("Are you sure you want to delete \"" + username.getText().toString() + "\"?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                listener.onDelete(user.split("@")[9]); // Call deletion
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });

        return convertView;
    }

    public interface OnDeleteClickListener {
        void onDelete(String userId);

        void onClicked(String user);
    }
}