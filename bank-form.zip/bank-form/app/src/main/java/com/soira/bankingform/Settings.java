package com.soira.bankingform;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import static com.soira.bankingform.tool.Data.ALPHA;
import static com.soira.bankingform.tool.Data.bank_cities;
import static com.soira.bankingform.tool.Data.isValid;

public class Settings extends AppCompatActivity {

    TextInputEditText fortynine, fiftyone, fiftythree;
    AutoCompleteTextView place_of_registration;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);
        sharedPreferences = getSharedPreferences("SETTING", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        fortynine = (TextInputEditText) findViewById(R.id.fortynine);
        place_of_registration = (AutoCompleteTextView) findViewById(R.id.place_of_registration);
        fiftyone = (TextInputEditText) findViewById(R.id.fiftyone);
        fiftythree = (TextInputEditText) findViewById(R.id.fiftythree);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                bank_cities);
        place_of_registration.setAdapter(adapter);

        String two = sharedPreferences.getString("two", null);
        String three = sharedPreferences.getString("three", null);
        String four = sharedPreferences.getString("four", null);
        String six = sharedPreferences.getString("six", null);

        fortynine.setText(two == null ? "" : two);
        place_of_registration.setText(three == null ? "" : three);
        fiftyone.setText(four == null ? "" : four);
        fiftythree.setText(six == null ? "" : six);


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (!sharedPreferences.getBoolean("SET", false)) {
            startActivity(new Intent(Settings.this, Intro.class).putExtra("exit", true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        }

    }

    private boolean good(String input) {
        input = input.trim();
        for (int j = 0; j < input.length(); j++) {
            String val = String.valueOf(input.charAt(j));
            if (!ALPHA.contains(val)) {
                return false;
            }
        }
        return true;
    }

    public void save_setting(View view) {
        String two = fortynine.getText().toString();
        String three = place_of_registration.getText().toString();
        String four = fiftyone.getText().toString();
        String six = fiftythree.getText().toString();

        if (two.isEmpty()) {
            if (fortynine.isFocusable()) {
                fortynine.requestFocus();
            }
            fortynine.setError("Empty data.");
            return;
        }
        if (three.isEmpty()) {
            if (place_of_registration.isFocusable()) {
                place_of_registration.requestFocus();
            }
            place_of_registration.setError("Empty data.");
            return;
        } else if (!isValid(three, bank_cities)) {
            if (place_of_registration.isFocusable()) {
                place_of_registration.requestFocus();
            }
            place_of_registration.setError("Invalid place.");
            return;
        }
        if (four.isEmpty()) {
            if (fiftyone.isFocusable()) {
                fiftyone.requestFocus();
            }
            fiftyone.setError("Empty data.");
            return;
        }
        if (six.isEmpty()) {
            if (fiftythree.isFocusable()) {
                fiftythree.requestFocus();
            }
            fiftythree.setError("Empty data.");
            return;
        }

        if (!good(two)) {
            if (fortynine.isFocusable()) {
                fortynine.requestFocus();
            }
            fortynine.setError("Enter correct name. Only English alphabets are allowed.");
            return;
        }
        if (!good(four)) {
            if (fiftyone.isFocusable()) {
                fiftyone.requestFocus();
            }
            fiftyone.setError("Enter correct name. Only English alphabets are allowed.");
            return;
        }
        if (!good(six)) {
            if (fiftythree.isFocusable()) {
                fiftythree.requestFocus();
            }
            fiftythree.setError("Enter correct name. Only English alphabets are allowed.");
            return;
        }

        editor.putString("two", two.trim()).apply();
        editor.putString("three", three.trim()).apply();
        editor.putString("four", four.trim()).apply();
        editor.putString("six", six.trim()).apply();

        editor.putBoolean("SET", true).apply();

        finish();
    }

    private boolean isAlpha(String[] vals) {
        boolean alpha = false;
        for (String entry : vals) {
            try {
                int val = Integer.valueOf(entry);
            } catch (Exception e) {
                alpha = true;
            }
        }
        return alpha;
    }
}
