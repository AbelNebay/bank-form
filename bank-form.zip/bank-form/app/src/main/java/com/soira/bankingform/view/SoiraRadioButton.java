package com.soira.bankingform.view;


import android.content.Context;
import android.util.AttributeSet;
import android.widget.RadioButton;

public class SoiraRadioButton extends RadioButton {

    public SoiraRadioButton(Context context) {
        super(context);
    }

    public SoiraRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SoiraRadioButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

}
