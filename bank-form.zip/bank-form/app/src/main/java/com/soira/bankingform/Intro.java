package com.soira.bankingform;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Intro extends AppCompatActivity {

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro);
        sharedPreferences = getSharedPreferences("SETTING", MODE_PRIVATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean exit = getIntent() != null && getIntent().getBooleanExtra("exit", false);
        if (exit) {
            finish();
            return;
        }
        boolean set = sharedPreferences.getBoolean("SET", false);
        if (!set) {
            setting(null);
        }
    }

    public void register(View view) {
        startActivity(new Intent(Intro.this, Register.class));
    }

    public void setting(View view) {
        startActivity(new Intent(Intro.this, Settings.class));
    }

    public void export(View view) {
        startActivity(new Intent(Intro.this, Export.class));
    }

    public void list_clients(View view) {
        startActivity(new Intent(Intro.this, ClientList.class));
    }
}
