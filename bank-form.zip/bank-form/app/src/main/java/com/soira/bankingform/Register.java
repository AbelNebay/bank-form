package com.soira.bankingform;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.soira.bankingform.database.Database;
import com.soira.bankingform.tool.Data;
import com.soira.bankingform.view.SoiraRadioButton;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.soira.bankingform.tool.Data.ACTUALS;
import static com.soira.bankingform.tool.Data.ALPHA;
import static com.soira.bankingform.tool.Data.all_jobs;
import static com.soira.bankingform.tool.Data.anseba;
import static com.soira.bankingform.tool.Data.bank_cities;
import static com.soira.bankingform.tool.Data.cities;
import static com.soira.bankingform.tool.Data.debub;
import static com.soira.bankingform.tool.Data.gash;
import static com.soira.bankingform.tool.Data.isValid;
import static com.soira.bankingform.tool.Data.maekel;
import static com.soira.bankingform.tool.Data.nationalities;
import static com.soira.bankingform.tool.Data.nrs;
import static com.soira.bankingform.tool.Data.sources;
import static com.soira.bankingform.tool.Data.srs;
import static com.soira.bankingform.tool.Data.zobas;

public class Register extends AppCompatActivity {

    public static String USERS = null;

    boolean EDIT_MODE = false;

    TextInputEditText full_name, birth_year, mother_name, personal_street, personal_house_no, eritrean_id,
            passport_no, residence_id, personal_phone_no, name_of_work_owner, work_house_no, work_name, trading_type,
            tin_no, asr_no, asl_no, license_no, bank_account_no, amount_of_cash_on_hand, if_other_specify,
            name_contact_person, relation_contact_person, phone_contact_person,
            registrar_name, name_of_receiver, date_of_registration, name_of_controller;
    SoiraRadioButton male, female;
    Spinner bank_name, how_long_on_hand;
    CheckBox is_owner, consumption, emergency, trading, house_rent, other, permanent_phone_no;

    ArrayAdapter<CharSequence> spinner_adapter, jobs_adapter;
    AutoCompleteTextView nationality, bank_division, personal_zoba, work_zoba, personal_sub, work_sub, source_of_cash, work_type, place_of_registration;
    String[] personal_selected = null, work_selected = null;

    SharedPreferences sharedPreferences;
    LinearLayout containerLayout, containerSource, containerWork;
    LayoutInflater inflater;
    Button add_bank, add_source, add_work;
    ImageView cleanWork, cleanSource;
    boolean isEditing;
    ArrayAdapter<String> adapter, zoba_adapter, nation_adapter, source_adapter;
    ScrollView register_form;
    boolean BRAIN = false;
    ArrayList<View> texts = new ArrayList<>();
    int CURRENT_FOCUS = -1;

    String prev_name_owner = "", prev_work_zoba = "", prev_work_sub = "", prev_house_no = "";
    boolean prev_is_owner = false;
    String PREV_ID, PREV_ACCOUNT;

    @Override
    protected void onStop() {
        super.onStop();
        USERS = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (USERS != null) {
            setValues();
        }
        initAutoValidations();
    }

    private void setValues() {
        String[] ENTRY = USERS.split("@");

        full_name.setText(ENTRY[0]);
        String gender = ENTRY[1];
        if (gender.equals("Male")) {
            male.setChecked(true);
            female.setChecked(false);
        } else {
            male.setChecked(false);
            female.setChecked(true);
        }
        birth_year.setText(ENTRY[2]);
        mother_name.setText(ENTRY[3]);

        personal_zoba.setText(ENTRY[4]);
        personal_sub.setText(ENTRY[5]);
        personal_street.setText(ENTRY[6]);
        personal_house_no.setText(ENTRY[7]);
        nationality.setText(ENTRY[8]);
        eritrean_id.setText(ENTRY[9]);
        PREV_ID = ENTRY[9];
        passport_no.setText(ENTRY[10]);
        residence_id.setText(ENTRY[11]);
        personal_phone_no.setText(ENTRY[12]);
        work_type.setText(ENTRY[13]);

        String owner = ENTRY[14];
        if (!owner.isEmpty()) {
            is_owner.setChecked(true);
        } else {
            is_owner.setChecked(false);
        }
        name_of_work_owner.setText(ENTRY[15]);
        work_zoba.setText(ENTRY[16]);
        work_sub.setText(ENTRY[17]);
        work_house_no.setText(ENTRY[18]);

        String value = ENTRY[19];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    work_name.setText(entry);
                    i++;
                    continue;
                }
                addWorkRow();
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.work_name_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            work_name.setText(value);
        }

        value = ENTRY[20];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    trading_type.setText(entry);
                    i++;
                    continue;
                }
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.trading_type_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i + 1);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            trading_type.setText(value);
        }

        value = ENTRY[21];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    tin_no.setText(entry);
                    i++;
                    continue;
                }
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.tin_no_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i + 2);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            tin_no.setText(value);
        }

        value = ENTRY[22];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    asr_no.setText(entry);
                    i++;
                    continue;
                }
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.asr_no_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i + 3);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            asr_no.setText(value);
        }

        value = ENTRY[23];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    asl_no.setText(entry);
                    i++;
                    continue;
                }
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.asl_no_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i + 4);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            asl_no.setText(value);
        }

        value = ENTRY[24];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    license_no.setText(entry);
                    i++;
                    continue;
                }
                View row = containerWork.getChildAt(i - 1);
                EditText work_name = (EditText) row.findViewById(R.id.license_no_row);

                if (work_name == null) {
                    work_name = (EditText) ((ViewGroup) row).getChildAt(i + 5);
                }
                work_name.setText(entry);
                i++;
            }
        } else {
            license_no.setText(value);
        }

        value = ENTRY[25];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    bank_account_no.setText(entry);
                    i++;
                    continue;
                }
                addNewRow();
                View row = containerLayout.getChildAt(i - 1);
                EditText bank_code = (EditText) row.findViewById(R.id.bank_code);

                if (bank_code == null) {
                    bank_code = (EditText) ((ViewGroup) row).getChildAt(i);
                }
                bank_code.setText(entry);
                i++;
            }
        } else {
            bank_account_no.setText(value);
        }
        PREV_ACCOUNT = bank_account_no.getText().toString();

        String first = ENTRY[26];

        if (first.contains("-")) {
            String[] data = first.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    switch (entry) {
                        case "Commercial Bank":
                            bank_name.setSelection(0);
                            break;
                        case "Housing & Commerce Bank":
                            bank_name.setSelection(1);
                            break;
                        case "Investment & Development Bank":
                            bank_name.setSelection(2);
                            break;
                    }
                    i++;
                    continue;
                }

                View row = containerLayout.getChildAt(i - 1);
                Spinner bank_name = (Spinner) row.findViewById(R.id.bank_name);

                if (bank_name == null) {
                    bank_name = (Spinner) ((ViewGroup) row).getChildAt(i + 2);
                }
                switch (entry) {
                    case "Commercial Bank":
                        bank_name.setSelection(0);
                        break;
                    case "Housing & Commerce Bank":
                        bank_name.setSelection(1);
                        break;
                    case "Investment & Development Bank":
                        bank_name.setSelection(2);
                        break;
                }
                i++;
            }
        } else {
            switch (first) {
                case "Commercial Bank":
                    bank_name.setSelection(0);
                    break;
                case "Housing & Commerce Bank":
                    bank_name.setSelection(1);
                    break;
                case "Investment & Development Bank":
                    bank_name.setSelection(2);
                    break;
            }
        }

        value = ENTRY[27];
        if (value.contains("-")) {
            String[] data = value.split("-");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    bank_division.setText(entry);
                    i++;
                    continue;
                }

                View row = containerLayout.getChildAt(i - 1);
                AutoCompleteTextView bank_division = (AutoCompleteTextView) row.findViewById(R.id.bank_division);

                if (bank_division == null) {
                    bank_division = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(i + 3);
                }
                bank_division.setText(entry);
                i++;
            }
        } else {
            bank_division.setText(value);
        }

        String money = ENTRY[28];
        if (!money.equals("")) {
            try {
                double parsed = Double.parseDouble(money);
                NumberFormat formatter = new DecimalFormat("#,###");
                String formatted = formatter.format(parsed);
                amount_of_cash_on_hand.setText(formatted);
                amount_of_cash_on_hand.setSelection(amount_of_cash_on_hand.getText().length());
            } catch (Exception ignored) {
            }
        }
        String[] tips = ENTRY[29].split("-");

        for (String entry : tips) {
            switch (entry) {
                case "Consumption":
                    consumption.setChecked(true);
                    break;
                case "Emergency":
                    emergency.setChecked(true);
                    break;
                case "Trading":
                    trading.setChecked(true);
                    break;
                case "House rent":
                    house_rent.setChecked(true);
                    break;
                case "Other":
                    other.setChecked(true);
                    break;
            }
        }

        if_other_specify.setText(ENTRY[30]);

        String source = ENTRY[31];
        if (source.contains("=")) {
            String[] data = source.split("=");
            int i = 0;
            for (String entry : data) {
                if (i == 0) {
                    source_of_cash.setText(entry);
                    i++;
                    continue;
                }
                addSourceRow();
                View row = containerSource.getChildAt(i - 1);
                AutoCompleteTextView bank_code = (AutoCompleteTextView) row.findViewById(R.id.source_of_cash_row);

                if (bank_code == null) {
                    bank_code = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(i + 1);
                }
                bank_code.setText(entry);
                i++;
            }
        } else {
            source_of_cash.setText(source);
        }

        String duration = ENTRY[32];
        switch (duration) {
            case "1–6 Months":
                how_long_on_hand.setSelection(0);
                break;
            case "6–12 Months":
                how_long_on_hand.setSelection(1);
                break;
            case "1–5 Years":
                how_long_on_hand.setSelection(2);
                break;
            case "Above 5 Years":
                how_long_on_hand.setSelection(3);
                break;
        }

        name_contact_person.setText(ENTRY[33]);
        relation_contact_person.setText(ENTRY[34]);
        phone_contact_person.setText(ENTRY[35]);

        String permanent = ENTRY[36];
        if (!permanent.isEmpty()) {
            permanent_phone_no.setChecked(true);
        } else {
            permanent_phone_no.setChecked(false);
        }

        registrar_name.setText(ENTRY[37]);
        place_of_registration.setText(ENTRY[38]);
        name_of_receiver.setText(ENTRY[39]);
        date_of_registration.setText(ENTRY[40]);
        name_of_controller.setText(ENTRY[41]);
    }

    public void save(View view) {
        String[] banks = fetchBanks();
        String[] works = fetchWorks();
        String[] sources = fetchSources();

        ArrayList<String> data = new ArrayList<>();
        String whole_check = "", value = "", gender = "";
        boolean checked;

        data.add(full_name.getText().toString());
        checked = male.isChecked();
        if (checked) {
            gender = "Male";
        } else {
            gender = "Female";
        }
        data.add(gender);
        data.add(birth_year.getText().toString().replaceAll("#", "_"));
        data.add(mother_name.getText().toString().replaceAll("#", "_"));
        value = personal_zoba.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        value = personal_sub.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        data.add(personal_street.getText().toString().replaceAll("#", "_"));
        data.add(personal_house_no.getText().toString().replaceAll("#", "_"));
        data.add(nationality.getText().toString().replaceAll("#", "_"));
        data.add(eritrean_id.getText().toString().replaceAll("#", "_"));
        data.add(passport_no.getText().toString().replaceAll("#", "_").toUpperCase());
        data.add(residence_id.getText().toString().replaceAll("#", "_").toUpperCase());
        data.add(personal_phone_no.getText().toString().replaceAll("#", "_"));
        data.add(work_type.getText().toString().replaceAll("#", "_"));
        checked = is_owner.isChecked();
        if (checked) {
            data.add("Owner");
        } else {
            data.add("");
        }
        data.add(name_of_work_owner.getText().toString().replaceAll("#", "_"));

        value = work_zoba.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        value = work_sub.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        data.add(work_house_no.getText().toString().replaceAll("#", "_"));

        value = work_name.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[0];
            }
        }
        data.add(value);

        value = trading_type.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[1];
            }
        }
        data.add(value);

        value = tin_no.getText().toString().toUpperCase().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[2];
            }
        }
        data.add(value);

        value = asr_no.getText().toString().toUpperCase().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[3];
            }
        }
        data.add(value);

        value = asl_no.getText().toString().toUpperCase().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[4];
            }
        }
        data.add(value);

        value = license_no.getText().toString().toUpperCase().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[5];
            }
        }
        data.add(value);

        value = bank_account_no.getText().toString().replaceAll("#", "_").replace("-", "_").toUpperCase();
        if (banks != null) {
            for (String entry : banks) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[0];
            }
        }
        data.add(value);

        value = bank_name.getSelectedItem().toString();
        if (banks != null) {
            for (String entry : banks) {
                value += "-" + entry.replace("-", "_").split(" # ")[1];
            }
        }
        data.add(value);
        value = bank_division.getText().toString();
        value = value.replaceAll("#", "_");
        if (banks != null) {
            for (String entry : banks) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").split(" # ")[2];
            }
        }
        data.add(value);

        value = amount_of_cash_on_hand.getText().toString().replace(",", "").replaceAll("#", "_");
        data.add(value);

        checked = consumption.isChecked();
        if (checked) {
            whole_check += "Consumption-";
        }
        checked = emergency.isChecked();
        if (checked) {
            whole_check += "Emergency-";
        }
        checked = trading.isChecked();
        if (checked) {
            whole_check += "Trading-";
        }
        checked = house_rent.isChecked();
        if (checked) {
            whole_check += "House rent-";
        }

        checked = other.isChecked();
        if (checked) {
            whole_check += "Other";
        }
        if (whole_check.endsWith("-")) {
            whole_check = whole_check.substring(0, whole_check.length() - 1);
        }
        data.add(whole_check);
        data.add(if_other_specify.getText().toString().replaceAll("#", "_"));
        value = source_of_cash.getText().toString().replaceAll("#", "_");
        if (sources != null) {
            for (String entry : sources) {
                if (value.isEmpty()) {
                    break;
                }
                value += "=" + entry.replace("=", "_").replace(",", "").
                        replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            }
        }

        data.add(value);

        value = how_long_on_hand.getSelectedItem().toString();
        data.add(value);

        data.add(name_contact_person.getText().toString().replaceAll("#", "_"));
        data.add(relation_contact_person.getText().toString().replaceAll("#", "_"));
        data.add(phone_contact_person.getText().toString().replaceAll("#", "_"));
        checked = permanent_phone_no.isChecked();
        if (checked) {
            data.add("Permanent");
        } else {
            data.add("");
        }
        data.add(registrar_name.getText().toString().replaceAll("#", "_"));
        data.add(place_of_registration.getText().toString().replaceAll("#", "_"));
        data.add(name_of_receiver.getText().toString().replaceAll("#", "_"));
        data.add(date_of_registration.getText().toString().replaceAll("#", "_"));
        data.add(name_of_controller.getText().toString().replaceAll("#", "_"));


        int i = 1;
        ArrayList<Integer> options = new ArrayList<>();
        options.add(7);
        options.add(8);
        options.add(9);
        options.add(11);
        options.add(15);
        options.add(19);
        options.add(20);
        options.add(21);
        options.add(22);
        options.add(23);
        options.add(24);
        options.add(25);
        options.add(27);
        options.add(31);
        options.add(33);
        options.add(37);

//        boolean all_blank = data.get(21).isEmpty() &&
//                data.get(22).isEmpty() &&
//                data.get(23).isEmpty() &&
//                data.get(24).isEmpty() &&
//                data.get(25).isEmpty() &&
//                data.get(26).isEmpty();

        for (String entry : data) {
            if (!options.contains(i) && entry.isEmpty()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Empty Data");
                builder.setMessage(ACTUALS[i - 1] + " is empty.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                return;
            }
            if (entry.contains("’") || entry.contains("#") || entry.contains(",") || entry.contains("@") || entry.contains("\'") || entry.contains("\"") || entry.contains("?")) {
                String message = "On " + ACTUALS[i - 1] + " ,#@’”? are not allowed.";
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Input Error");
                builder.setMessage(message);
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                return;
            }

            // CUSTOMS //
            if (i == 1) {
                String name = full_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Full Name Error");
                        builder.setMessage("Enter correct name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 3) {
                try {
                    int year = Integer.valueOf(entry);
                    if (year < 1900 || year > 2010) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Birth Error");
                        builder.setMessage("Enter birth year between 1900-2010.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                } catch (Exception e) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Birth Error");
                    builder.setMessage("Enter valid birth year. [Ex. 1900-2010]");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }
            if (i == 4) {
                String name = mother_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Mother Name Error");
                        builder.setMessage("Enter correct mother name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 6 && !isValid(personal_sub.getText().toString(), personal_selected)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Regional Error");
                builder.setMessage("Living Subzone is not valid.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                return;
            }
            if (i == 9) {
                String name = nationality.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Nationality Error");
                        builder.setMessage("Enter correct nationality. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 10) {
                if (!entry.matches("\\d{6}-\\d{5}")) {
                    if (entry.length() != 7) {
                        String message = ACTUALS[i - 1] + " is mistyped.";
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Input Error");
                        builder.setMessage(message);
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }

            if (i == 12) {
                String word = residence_id.getText().toString().toLowerCase();
                if (!word.startsWith("asc") &&
                        !word.startsWith("gbc") &&
                        !word.startsWith("kec") &&
                        !word.startsWith("zdc") &&
                        !word.startsWith("skc") &&
                        !word.startsWith("dkc")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Residence Error");
                    builder.setMessage("Residence Zoba code is incorrect.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                } else if (word.length() != 11) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Residence Error");
                    builder.setMessage("Residence ID is mistyped.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                } else {
                    word = word.substring(3);
                    boolean clean;
                    try {
                        Integer.valueOf(word);
                        clean = true;
                    } catch (Exception e) {
                        clean = false;
                    }
                    if (!clean) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Residence Error");
                        builder.setMessage("Residence ID is mistyped. Has to be a number after the zoba code.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 13) {
                String word = personal_phone_no.getText().toString();
                boolean clean;
                try {
                    Integer.valueOf(word);
                    clean = true;
                } catch (Exception e) {
                    clean = false;
                }
                if (clean && word.startsWith("07") && word.length() == 8) {

                } else if (word.startsWith("08") && word.length() == 8 && clean) {

                } else if (word.length() == 6 && !word.startsWith("0") && clean) {

                } else {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Phone Error");
                    builder.setMessage("Personal phone number is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }

            if (i == 14) {
                String word = work_type.getText().toString();
                if (!isValid(word, all_jobs)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Work type Error");
                    builder.setMessage("Work type is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }

            if (i == 18 && !isValid(work_sub.getText().toString(), work_selected)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Regional Error");
                builder.setMessage("Working Subzone is not valid.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                return;
            }

            if (i == 28) {
                int n = 1;
                for (String val : entry.split("-")) {
                    if (!isValid(val, bank_cities)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Bank Branch Error");
                        builder.setMessage("Bank branch #" + String.valueOf(n) + " is not valid.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                    n++;
                }
            }

            if (i == 30) {
                if (entry.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Cash Usage Error");
                    builder.setMessage("Please check at least one box from the \"Purpose of cash held\" options.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }
            if (i == 31) {
                checked = other.isChecked();
                String specify = if_other_specify.getText().toString();
                if (checked && (specify.isEmpty())) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Empty Data");
                    builder.setMessage("Purpose of cash held is not specified.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
                if (!specify.isEmpty() && (specify.contains("#") ||
                        specify.contains(",") ||
                        specify.contains("@") ||
                        specify.contains("\'") ||
                        specify.contains("\"") ||
                        specify.contains("?"))) {
                    String message = "Specified purpose of cash held contains ,#@’”? letters.";
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Input Error");
                    builder.setMessage(message);
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }
            if (i == 32) {
                int n = 1;
                for (String val : entry.split("=")) {
                    if (!isValid(val, Data.sources)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Source of cash Error");
                        builder.setMessage("Source of cash #" + String.valueOf(n) + " is not valid.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                    n++;
                }
            }
            if (i == 34) {
                String name = name_contact_person.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Contact Person Name Error");
                        builder.setMessage("Enter correct contact person name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 36) {
                String word = phone_contact_person.getText().toString();
                boolean clean;
                try {
                    Integer.valueOf(word);
                    clean = true;
                } catch (Exception e) {
                    clean = false;
                }
                if (clean && word.startsWith("07") && word.length() == 8) {

                } else if (word.startsWith("08") && word.length() == 8 && clean) {

                } else if (word.length() == 6 && !word.startsWith("0") && clean) {

                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Phone Error");
                    builder.setMessage("Contact person phone number is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }
            if (i == 38) {
                String name = registrar_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Registrar Person Name Error");
                        builder.setMessage("Enter correct registrar name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 39) {
                if (!isValid(entry, bank_cities)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Input Error");
                    builder.setMessage("Place of registration is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    return;
                }
            }
            if (i == 40) {
                String name = name_of_receiver.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Receiver Name Error");
                        builder.setMessage("Enter correct receiver\'s name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            if (i == 42) {
                String name = name_of_controller.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Controller Name Error");
                        builder.setMessage("Enter correct controller\'s name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            i++;
        }

        try {
            String entered_value = eritrean_id.getText().toString();
            if (USERS != null && !USERS.split("@")[9].equals(entered_value)) {
                USERS = null;
            }
        } catch (Exception ignored) {
        }

        String original_data = "";
        int post = 0;
        String eri_id = "";
        for (String entry : data) {
            if (post == 9) {
                eri_id = entry;
            }
            original_data += entry.trim() + "@";
            post++;
        }
        original_data = original_data.substring(0, original_data.length() - 1);

        Database database = new Database(this);

        if (PREV_ACCOUNT != null) {
            EDIT_MODE = PREV_ACCOUNT.equalsIgnoreCase(bank_account_no.getText().toString());
        }

        boolean deleted = false;
        if (EDIT_MODE && PREV_ID != null) {
            deleted = database.deleteData(PREV_ID);
        }

        if (USERS == null || deleted) {
            boolean inserted = database.insertData(eri_id, original_data);
            if (inserted) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle(deleted ? "Edited" : "Registered");
                builder.setMessage(deleted ? "Successfully edited!" : "Successfully registered!");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                refresh_all();

            } else {
                boolean updated = database.updateWhole(eri_id, original_data);
                if (updated) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Registered");
                    builder.setMessage("Successfully registered!");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    refresh_all();

                } else {
                    new AlertDialog.Builder(Register.this)
                            .setTitle("Registering Error")
                            .setMessage("Registering failed. Try again!")
                            .setPositiveButton("OK", null)
                            .show();
                }
            }
        } else {
            boolean updated = database.updateWhole(eri_id, original_data);
            if (updated) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Updated");
                builder.setMessage("Successfully updated!");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                alert.show();
                refresh_all();

            } else {
                new AlertDialog.Builder(Register.this)
                        .setTitle("Update Error")
                        .setMessage("Updating failed. Try again!")
                        .setPositiveButton("OK", null)
                        .show();
            }
        }
        EDIT_MODE = false;

    }

    public void checkValidity(final View view, final int index) {
        if (BRAIN) {
            BRAIN = false;
            return;
        }
        String[] banks = fetchBanks();
        String[] works = fetchWorks();
        String[] sources = fetchSources();

        ArrayList<String> data = new ArrayList<>();
        String whole_check = "", value = "", gender = "";
        boolean checked;

        data.add(full_name.getText().toString().replaceAll("#", "_"));
        checked = male.isChecked();
        if (checked) {
            gender = "Male";
        } else {
            gender = "Female";
        }
        data.add(gender);
        data.add(birth_year.getText().toString().replaceAll("#", "_"));
        data.add(mother_name.getText().toString().replaceAll("#", "_"));
        value = personal_zoba.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        value = personal_sub.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        data.add(personal_street.getText().toString().replaceAll("#", "_"));
        data.add(personal_house_no.getText().toString().replaceAll("#", "_"));
        data.add(nationality.getText().toString().replaceAll("#", "_"));
        data.add(eritrean_id.getText().toString().replaceAll("#", "_"));
        data.add(passport_no.getText().toString().replaceAll("#", "_"));
        data.add(residence_id.getText().toString().replaceAll("#", "_"));
        data.add(personal_phone_no.getText().toString().replaceAll("#", "_"));
        data.add(work_type.getText().toString().replaceAll("#", "_"));
        checked = is_owner.isChecked();
        if (checked) {
            data.add("Owner");
        } else {
            data.add("");
        }
        data.add(name_of_work_owner.getText().toString().replaceAll("#", "_"));

        value = work_zoba.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        value = work_sub.getText().toString();
        value = value.replaceAll("#", "_");
        data.add(value);
        data.add(work_house_no.getText().toString().replaceAll("#", "_"));


        value = work_name.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[0];
            }
        }
        data.add(value);

        value = trading_type.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[1];
            }
        }
        data.add(value);

        value = tin_no.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[2];
            }
        }
        data.add(value);

        value = asr_no.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[3];
            }
        }
        data.add(value);

        value = asl_no.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[4];
            }
        }
        data.add(value);

        value = license_no.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (works != null) {
            for (String entry : works) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[5];
            }
        }
        data.add(value);

        value = bank_account_no.getText().toString().replaceAll("#", "_").replace("-", "_");
        if (banks != null) {
            for (String entry : banks) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").replace(",", "_").split(" # ")[0];
            }
        }
        data.add(value);

        value = bank_name.getSelectedItem().toString();
        if (banks != null) {
            for (String entry : banks) {
                value += "-" + entry.replace("-", "_").split(" # ")[1];
            }
        }
        data.add(value);
        value = bank_division.getText().toString();
        value = value.replaceAll("#", "_");
        if (banks != null) {
            for (String entry : banks) {
                if (value.isEmpty()) {
                    break;
                }
                value += "-" + entry.replace("-", "_").split(" # ")[2];
            }
        }
        data.add(value);

        value = amount_of_cash_on_hand.getText().toString().replace(",", "").replaceAll("#", "_");
        data.add(value);

        checked = consumption.isChecked();
        if (checked) {
            whole_check += "Consumption-";
        }
        checked = emergency.isChecked();
        if (checked) {
            whole_check += "Emergency-";
        }
        checked = trading.isChecked();
        if (checked) {
            whole_check += "Trading-";
        }
        checked = house_rent.isChecked();
        if (checked) {
            whole_check += "House rent-";
        }

        checked = other.isChecked();
        if (checked) {
            whole_check += "Other";
        }
        if (whole_check.endsWith("-")) {
            whole_check = whole_check.substring(0, whole_check.length() - 1);
        }
        data.add(whole_check);
        data.add(if_other_specify.getText().toString().replaceAll("#", "_"));
        value = source_of_cash.getText().toString().replaceAll("#", "_");
        if (sources != null) {
            for (String entry : sources) {
                if (value.isEmpty()) {
                    break;
                }
                value += "=" + entry.replace("=", "_").replace(",", "").
                        replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            }
        }

        data.add(value);

        value = how_long_on_hand.getSelectedItem().toString();
        data.add(value);

        data.add(name_contact_person.getText().toString().replaceAll("#", "_"));
        data.add(relation_contact_person.getText().toString().replaceAll("#", "_"));
        data.add(phone_contact_person.getText().toString().replaceAll("#", "_"));
        checked = permanent_phone_no.isChecked();
        if (checked) {
            data.add("Permanent");
        } else {
            data.add("");
        }
        data.add(registrar_name.getText().toString().replaceAll("#", "_"));
        data.add(place_of_registration.getText().toString().replaceAll("#", "_"));
        data.add(name_of_receiver.getText().toString().replaceAll("#", "_"));
        data.add(date_of_registration.getText().toString().replaceAll("#", "_"));
        data.add(name_of_controller.getText().toString().replaceAll("#", "_"));

        int i = 1;
        ArrayList<Integer> options = new ArrayList<>();
        options.add(7);
        options.add(8);
        options.add(9);
        options.add(11);
        options.add(15);
        options.add(19);
        options.add(20);
        options.add(21);
        options.add(22);
        options.add(23);
        options.add(24);
        options.add(25);
        options.add(27);
        options.add(31);
        options.add(33);
        options.add(37);

        for (String entry : data) {
            if (index >= i && !options.contains(i) && entry.isEmpty()) {
                BRAIN = true;
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Empty Data");
                builder.setMessage(ACTUALS[i - 1] + " is empty.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                final int in = i;
                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        if (CURRENT_FOCUS < index) {
                            return;
                        }
                        view.clearFocus();
                        fireFocusAt(in - 1);
                    }
                });
                alert.show();
                return;
            }
            if (index >= i && (entry.contains("’") || entry.contains("#") || entry.contains(",") || entry.contains("@") || entry.contains("\'") || entry.contains("\"") || entry.contains("?"))) {
                BRAIN = true;
                String message = "On " + ACTUALS[i - 1] + " ,#@’”? are not allowed.";
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Input Error");
                builder.setMessage(message);
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                final int in = i;
                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        if (CURRENT_FOCUS < index) {
                            return;
                        }
                        view.clearFocus();
                        fireFocusAt(in - 1);
                    }
                });
                alert.show();
                return;
            }

            // CUSTOMS //
            if (index >= i && i == 1) {
                String name = full_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Full Name Error");
                        builder.setMessage("Enter correct name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 3) {
                try {
                    int year = Integer.valueOf(entry);
                    if (year < 1900 || year > 2010) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Birth Error");
                        builder.setMessage("Enter birth year between 1900-2010.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                } catch (Exception e) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Birth Error");
                    builder.setMessage("Enter valid birth year. [Ex. 1900-2010]");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }
            if (index >= i && i == 4) {
                String name = mother_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Mother Name Error");
                        builder.setMessage("Enter correct mother name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 6 && !isValid(personal_sub.getText().toString(), personal_selected)) {
                BRAIN = true;
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Regional Error");
                builder.setMessage("Living Subzone is not valid.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                final int in = i;
                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        if (CURRENT_FOCUS < index) {
                            return;
                        }
                        view.clearFocus();
                        fireFocusAt(in - 1);
                    }
                });
                alert.show();
                return;
            }
            if (index >= i && i == 9) {
                String name = nationality.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Nationality Error");
                        builder.setMessage("Enter correct nationality. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 10) {
                if (!entry.matches("\\d{6}-\\d{5}")) {
                    if (entry.length() != 7) {
                        BRAIN = true;
                        String message = ACTUALS[i - 1] + " is mistyped.";
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Input Error");
                        builder.setMessage(message);
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }

            if (index >= i && i == 12) {
                String word = residence_id.getText().toString().toLowerCase();
                if (!word.startsWith("asc") &&
                        !word.startsWith("gbc") &&
                        !word.startsWith("kec") &&
                        !word.startsWith("zdc") &&
                        !word.startsWith("skc") &&
                        !word.startsWith("dkc")) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Residence Error");
                    builder.setMessage("Residence Zoba code is incorrect.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                } else if (word.length() != 11) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Residence Error");
                    builder.setMessage("Residence ID is mistyped.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                } else {
                    word = word.substring(3);
                    boolean clean;
                    try {
                        Integer.valueOf(word);
                        clean = true;
                    } catch (Exception e) {
                        clean = false;
                    }
                    if (!clean) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Residence Error");
                        builder.setMessage("Residence ID is mistyped. Has to be a number after the zoba code.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 13) {
                String word = personal_phone_no.getText().toString();
                boolean clean;
                try {
                    Integer.valueOf(word);
                    clean = true;
                } catch (Exception e) {
                    clean = false;
                }
                if (clean && word.startsWith("07") && word.length() == 8) {

                } else if (word.startsWith("08") && word.length() == 8 && clean) {

                } else if (word.length() == 6 && !word.startsWith("0") && clean) {

                } else {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Phone Error");
                    builder.setMessage("Personal phone number is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }

            if (index >= i && i == 14) {
                String word = work_type.getText().toString();
                if (!isValid(word, all_jobs)) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Work type Error");
                    builder.setMessage("Work type is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            work_type.setText("");
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }

            if (index >= i && i == 18 && !isValid(work_sub.getText().toString(), work_selected)) {
                BRAIN = true;
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Regional Error");
                builder.setMessage("Working Subzone is not valid.");
                builder.setPositiveButton("OK", null);
                AlertDialog alert = builder.create();
                final int in = i;
                alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        if (CURRENT_FOCUS < index) {
                            return;
                        }
                        view.clearFocus();
                        fireFocusAt(in - 1);
                    }
                });
                alert.show();
                return;
            }

            if (index >= i && i == 28) {
                int n = 1;
                for (String val : entry.split("-")) {
                    if (!isValid(val, bank_cities)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Bank Branch Error");
                        builder.setMessage("Bank branch #" + String.valueOf(n) + " is not valid.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                    n++;
                }
            }

            if (index >= i && i == 30) {
                if (entry.isEmpty()) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Cash Usage Error");
                    builder.setMessage("Please check at least one box from the \"Purpose of cash held\" options.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }
            if (index >= i && i == 31) {
                checked = other.isChecked();
                String specify = if_other_specify.getText().toString();
                if (checked && (specify.isEmpty())) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Empty Data");
                    builder.setMessage("Purpose of cash held is not specified.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
                if (!specify.isEmpty() && (specify.contains("#") ||
                        specify.contains(",") ||
                        specify.contains("@") ||
                        specify.contains("\'") ||
                        specify.contains("\"") ||
                        specify.contains("?"))) {
                    BRAIN = true;
                    String message = "Specified purpose of cash held contains ,#@’”? letters.";
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Input Error");
                    builder.setMessage(message);
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }
            if (index >= i && i == 32) {
                int n = 1;
                for (String val : entry.split("=")) {
                    if (!isValid(val, Data.sources)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Source of cash Error");
                        builder.setMessage("Source of cash #" + String.valueOf(n) + " is not valid.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                    n++;
                }
            }
            if (index >= i && i == 34) {
                String name = name_contact_person.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Contact Person Name Error");
                        builder.setMessage("Enter correct contact person name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 36) {
                String word = phone_contact_person.getText().toString();
                boolean clean;
                try {
                    Integer.valueOf(word);
                    clean = true;
                } catch (Exception e) {
                    clean = false;
                }
                if (clean && word.startsWith("07") && word.length() == 8) {

                } else if (word.startsWith("08") && word.length() == 8 && clean) {

                } else if (word.length() == 6 && !word.startsWith("0") && clean) {

                } else {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Phone Error");
                    builder.setMessage("Contact person phone number is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }
            if (index >= i && i == 38) {
                String name = registrar_name.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Registrar Person Name Error");
                        builder.setMessage("Enter correct registrar name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 39) {
                String word = place_of_registration.getText().toString();
                if (!isValid(word, bank_cities)) {
                    BRAIN = true;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    builder.setTitle("Input Error");
                    builder.setMessage("Place of registration is not valid.");
                    builder.setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    final int in = i;
                    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            if (CURRENT_FOCUS < index) {
                                return;
                            }
                            view.clearFocus();
                            fireFocusAt(in - 1);
                        }
                    });
                    alert.show();
                    return;
                }
            }
            if (index >= i && i == 40) {
                String name = name_of_receiver.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Receiver Name Error");
                        builder.setMessage("Enter correct receiver\'s name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        final int in = i;
                        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (CURRENT_FOCUS < index) {
                                    return;
                                }
                                view.clearFocus();
                                fireFocusAt(in - 1);
                            }
                        });
                        alert.show();
                        return;
                    }
                }
            }
            if (index >= i && i == 42) {
                String name = name_of_controller.getText().toString();
                for (int j = 0; j < name.length(); j++) {
                    String val = String.valueOf(name.charAt(j));
                    if (!ALPHA.contains(val)) {
                        BRAIN = true;
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("Controller Name Error");
                        builder.setMessage("Enter correct controller\'s name. Only English alphabets are allowed.");
                        builder.setPositiveButton("OK", null);
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                }
            }
            i++;
        }
    }

    private void fireFocusAt(int index) {
        texts.get(index).requestFocus();
    }

    private void refresh_all() {
        if (containerLayout != null && containerLayout.getChildCount() > 0) {
            containerLayout.removeAllViews();
        }
        if (containerWork != null && containerWork.getChildCount() > 0) {
            containerWork.removeAllViews();
        }
        if (containerSource != null && containerSource.getChildCount() > 0) {
            containerSource.removeAllViews();
        }
        bank_division.setText("");
        personal_zoba.setText("");
        work_zoba.setText("");

        full_name.setText("");
        birth_year.setText("");
        mother_name.setText("");
        personal_street.setText("");
        personal_house_no.setText("");
        nationality.setText("");
        eritrean_id.setText("");
        passport_no.setText("");
        residence_id.setText("");
        personal_phone_no.setText("");
        work_type.setText("");
        name_of_work_owner.setText("");
        work_house_no.setText("");
        work_name.setText("");
        trading_type.setText("");
        tin_no.setText("");
        asr_no.setText("");
        asl_no.setText("");
        license_no.setText("");
        bank_account_no.setText("");
        amount_of_cash_on_hand.setText("");
        if_other_specify.setText("");
        source_of_cash.setText("");
        name_contact_person.setText("");
        relation_contact_person.setText("");
        phone_contact_person.setText("");

        male.setChecked(true);
        female.setChecked(false);

        bank_name.setSelection(0);
        how_long_on_hand.setSelection(0);

        is_owner.setChecked(false);
        consumption.setChecked(false);
        emergency.setChecked(false);
        trading.setChecked(false);
        house_rent.setChecked(false);
        other.setChecked(false);
        permanent_phone_no.setChecked(false);

        try {
            register_form.setSmoothScrollingEnabled(true);
            register_form.smoothScrollTo(0, 0);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        sharedPreferences = getSharedPreferences("SETTING", MODE_PRIVATE);


        initViews();

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                bank_cities);

        source_adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                sources);

        zoba_adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                zobas);

        nation_adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                nationalities);

        spinner_adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_data, android.R.layout.simple_spinner_dropdown_item);

        jobs_adapter = ArrayAdapter.createFromResource(this,
                R.array.jobs_array, android.R.layout.simple_spinner_dropdown_item);

        nationality.setAdapter(nation_adapter);
        bank_division.setAdapter(adapter);
        personal_zoba.setAdapter(zoba_adapter);
        work_zoba.setAdapter(zoba_adapter);
        work_type.setAdapter(jobs_adapter);
        source_of_cash.setAdapter(source_adapter);

        work_type.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String job = s.toString();
                if (job.equalsIgnoreCase("unemployed")) {
                    prev_is_owner = is_owner.isChecked();
                    prev_name_owner = name_of_work_owner.getText().toString();
                    prev_work_zoba = work_zoba.getText().toString();
                    prev_work_sub = work_sub.getText().toString();
                    prev_house_no = work_house_no.getText().toString();

                    name_of_work_owner.setText("None");
                    is_owner.setChecked(false);
                    work_zoba.setText("Maekel");
                    work_sub.setText("Maekel Ketema");
                    work_house_no.setText("None");

                    is_owner.setEnabled(false);
                    name_of_work_owner.setEnabled(false);
                    work_zoba.setEnabled(false);
                    work_sub.setEnabled(false);
                    work_house_no.setEnabled(false);
                } else {
                    is_owner.setEnabled(true);
                    name_of_work_owner.setEnabled(true);
                    work_zoba.setEnabled(true);
                    work_sub.setEnabled(true);
                    work_house_no.setEnabled(true);

                    if (!prev_name_owner.isEmpty()) {
                        name_of_work_owner.setText(prev_name_owner);
                        is_owner.setChecked(prev_is_owner);
                    }
                    if (!prev_work_zoba.isEmpty()) {
                        work_zoba.setText(prev_work_zoba);
                    }
                    if (!prev_work_sub.isEmpty()) {
                        work_sub.setText(prev_work_sub);
                    }
                    if (!prev_house_no.isEmpty()) {
                        work_house_no.setText(prev_house_no);
                    }
                }
            }
        });

        place_of_registration.setAdapter(adapter);

        inflater = LayoutInflater.from(this);

        initialize_workers();

        cleanWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                work_type.setText("");
            }
        });

        cleanSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                source_of_cash.setText("");
            }
        });

        add_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewRow();
            }
        });

        add_work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWorkRow();
            }
        });
        add_source.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSourceRow();
            }
        });

        personal_zoba.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String zoba = s.toString();
                boolean enabled = isValid(zoba, zobas);
                personal_sub.setEnabled(enabled);
                if (!enabled) {
                    personal_sub.setText("");
                } else {
                    switch (zoba) {
                        case "Gash Barka":
                            personal_selected = gash;
                            break;
                        case "Maekel":
                            personal_selected = maekel;
                            break;
                        case "Anseba":
                            personal_selected = anseba;
                            break;
                        case "Debub":
                            personal_selected = debub;
                            break;
                        case "Northern Red Sea":
                            personal_selected = nrs;
                            break;
                        case "Southern Red Sea":
                            personal_selected = srs;
                            break;
                        default:
                            personal_selected = cities;
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Register.this,
                            android.R.layout.simple_dropdown_item_1line,
                            personal_selected);
                    personal_sub.setAdapter(adapter);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        work_zoba.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String zoba = s.toString();
                boolean enabled = isValid(zoba, zobas);
                work_sub.setEnabled(enabled);
                if (!enabled) {
                    work_sub.setText("");
                } else {
                    switch (zoba) {
                        case "Gash Barka":
                            work_selected = gash;
                            break;
                        case "Maekel":
                            work_selected = maekel;
                            break;
                        case "Anseba":
                            work_selected = anseba;
                            break;
                        case "Debub":
                            work_selected = debub;
                            break;
                        case "Northern Red Sea":
                            work_selected = nrs;
                            break;
                        case "Southern Red Sea":
                            work_selected = srs;
                            break;
                        default:
                            work_selected = cities;
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Register.this,
                            android.R.layout.simple_dropdown_item_1line,
                            work_selected);
                    work_sub.setAdapter(adapter);
                }
                if (work_type.getText().toString().equalsIgnoreCase("unemployed")) {
                    work_sub.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        eritrean_id.addTextChangedListener(new TextWatcher() {
            int previousLength = 0;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                previousLength = s.length();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isEditing) return;

                isEditing = true;

                String input = s.toString().replace("-", "");

                if (input.length() > 7) {
                    input = input.substring(0, 6) + "-" + input.substring(6);
                } else if (input.length() == 8 && previousLength < 7) {
                    input = input + "-";
                }

                eritrean_id.setText(input);
                eritrean_id.setSelection(input.length());

                isEditing = false;
            }
        });

        amount_of_cash_on_hand.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isEditing) return;

                isEditing = true;

                try {
                    String original = s.toString().replace(",", "");
                    if (!original.equals("")) {
                        double parsed = Double.parseDouble(original);
                        NumberFormat formatter = new DecimalFormat("#,###");
                        String formatted = formatter.format(parsed);
                        amount_of_cash_on_hand.setText(formatted);
                        amount_of_cash_on_hand.setSelection(amount_of_cash_on_hand.getText().length());
                    }
                } catch (NumberFormatException e) {
                }

                isEditing = false;
            }
        });

    }

    private void initAutoValidations() {
        full_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(full_name, 1);
                } else {
                    CURRENT_FOCUS = 1;
                }
            }
        });
        male.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    CURRENT_FOCUS = 2;
                }
                checkValidity(male, 2);
            }
        });
        female.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    CURRENT_FOCUS = 2;
                }
                checkValidity(female, 2);
            }
        });
        birth_year.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(birth_year, 3);
                } else {
                    CURRENT_FOCUS = 3;
                }
            }
        });
        mother_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(mother_name, 4);
                } else {
                    CURRENT_FOCUS = 4;
                }
            }
        });
        personal_zoba.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(personal_zoba, 5);
                } else {
                    CURRENT_FOCUS = 5;
                }
            }
        });
        personal_sub.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(personal_sub, 6);
                } else {
                    CURRENT_FOCUS = 6;
                }
            }
        });
        personal_street.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(personal_street, 7);
                } else {
                    CURRENT_FOCUS = 7;
                }
            }
        });
        personal_house_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(personal_house_no, 8);
                } else {
                    CURRENT_FOCUS = 8;
                }
            }
        });
        nationality.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(nationality, 9);
                } else {
                    CURRENT_FOCUS = 9;
                }
            }
        });
        eritrean_id.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(eritrean_id, 10);
                } else {
                    CURRENT_FOCUS = 10;
                }
            }
        });
        passport_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(passport_no, 11);
                } else {
                    CURRENT_FOCUS = 11;
                }
            }
        });
        residence_id.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(residence_id, 12);
                } else {
                    CURRENT_FOCUS = 12;
                }
            }
        });
        personal_phone_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(personal_phone_no, 13);
                } else {
                    CURRENT_FOCUS = 13;
                }
            }
        });
        work_type.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(work_type, 14);
                } else {
                    CURRENT_FOCUS = 14;
                }
            }
        });
        is_owner.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    CURRENT_FOCUS = 15;
                }
                checkValidity(is_owner, 15);
            }
        });
        name_of_work_owner.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(name_of_work_owner, 16);
                } else {
                    CURRENT_FOCUS = 16;
                }
            }
        });
        work_zoba.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(work_zoba, 17);
                } else {
                    CURRENT_FOCUS = 17;
                }
            }
        });
        work_sub.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(work_sub, 18);
                } else {
                    CURRENT_FOCUS = 18;
                }
            }
        });
        work_house_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(work_house_no, 19);
                } else {
                    CURRENT_FOCUS = 19;
                }
            }
        });
        work_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(work_name, 20);
                } else {
                    CURRENT_FOCUS = 20;
                }
            }
        });
        trading_type.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(trading_type, 21);
                } else {
                    CURRENT_FOCUS = 21;
                }
            }
        });
        tin_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(tin_no, 22);
                } else {
                    CURRENT_FOCUS = 22;
                }
            }
        });
        asr_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(asr_no, 23);
                } else {
                    CURRENT_FOCUS = 23;
                }
            }
        });
        asl_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(asl_no, 24);
                } else {
                    CURRENT_FOCUS = 24;
                }
            }
        });
        license_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(license_no, 25);
                } else {
                    CURRENT_FOCUS = 25;
                }
            }
        });
        bank_account_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(bank_account_no, 26);
                } else {
                    CURRENT_FOCUS = 26;
                }
            }
        });
        bank_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(bank_name, 27);
                } else {
                    CURRENT_FOCUS = 27;
                }
            }
        });
        bank_division.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(bank_division, 28);
                } else {
                    CURRENT_FOCUS = 28;
                }
            }
        });
        amount_of_cash_on_hand.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(amount_of_cash_on_hand, 29);
                } else {
                    CURRENT_FOCUS = 29;
                }
            }
        });
        consumption.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(consumption, 30);
                } else {
                    CURRENT_FOCUS = 30;
                }
            }
        });
        emergency.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(consumption, 30);
                } else {
                    CURRENT_FOCUS = 30;
                }
            }
        });
        trading.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(consumption, 30);
                } else {
                    CURRENT_FOCUS = 30;
                }
            }
        });
        house_rent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(consumption, 30);
                } else {
                    CURRENT_FOCUS = 30;
                }
            }
        });
        other.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(consumption, 30);
                } else {
                    CURRENT_FOCUS = 30;
                }
            }
        });
        if_other_specify.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(if_other_specify, 31);
                } else {
                    CURRENT_FOCUS = 31;
                }
            }
        });
        source_of_cash.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(source_of_cash, 32);
                } else {
                    CURRENT_FOCUS = 32;
                }
            }
        });
        how_long_on_hand.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(how_long_on_hand, 33);
                } else {
                    CURRENT_FOCUS = 33;
                }
            }
        });
        name_contact_person.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(name_contact_person, 34);
                } else {
                    CURRENT_FOCUS = 34;
                }
            }
        });
        relation_contact_person.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(relation_contact_person, 35);
                } else {
                    CURRENT_FOCUS = 35;
                }
            }
        });
        phone_contact_person.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(phone_contact_person, 36);
                } else {
                    CURRENT_FOCUS = 36;
                }
            }
        });
        permanent_phone_no.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    CURRENT_FOCUS = 37;
                }
                checkValidity(permanent_phone_no, 37);
            }
        });
        registrar_name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(registrar_name, 38);
                } else {
                    CURRENT_FOCUS = 38;
                }
            }
        });
        place_of_registration.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(place_of_registration, 39);
                } else {
                    CURRENT_FOCUS = 39;
                }
            }
        });
        name_of_receiver.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(name_of_receiver, 40);
                } else {
                    CURRENT_FOCUS = 40;
                }
            }
        });
        date_of_registration.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(date_of_registration, 41);
                } else {
                    CURRENT_FOCUS = 41;
                }
            }
        });
        name_of_controller.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    checkValidity(name_of_controller, 42);
                } else {
                    CURRENT_FOCUS = 42;
                }
            }
        });
    }

    private void validate(TextInputEditText view, int i) {
        String entry = view.getText().toString();
        i += 1;
        if (i == 10) {
            if (!entry.matches("\\d{6}-\\d{5}")) {
                if (entry.length() != 7) {
                    String message = ACTUALS[i - 1] + " is mistyped.";
                    view.requestFocus();
                    view.setError(message);
                    return;
                }
            }
        }
    }

    private void initViews() {

        cleanWork = (ImageView) findViewById(R.id.clean_work);
        cleanSource = (ImageView) findViewById(R.id.clean_source);

        containerLayout = (LinearLayout) findViewById(R.id.containerLayout);
        containerSource = (LinearLayout) findViewById(R.id.source_container);
        containerWork = (LinearLayout) findViewById(R.id.containerWork);
        register_form = (ScrollView) findViewById(R.id.register_form);
        add_bank = (Button) findViewById(R.id.add_bank);
        add_work = (Button) findViewById(R.id.add_work);
        add_source = (Button) findViewById(R.id.add_source);

        bank_division = (AutoCompleteTextView) findViewById(R.id.bank_branch);
        personal_zoba = (AutoCompleteTextView) findViewById(R.id.personal_zoba);
        personal_sub = (AutoCompleteTextView) findViewById(R.id.personal_sub_zoba);
        work_zoba = (AutoCompleteTextView) findViewById(R.id.work_zoba);
        work_sub = (AutoCompleteTextView) findViewById(R.id.work_sub_zoba);

        full_name = (TextInputEditText) findViewById(R.id.full_name);
        birth_year = (TextInputEditText) findViewById(R.id.birth_year);
        mother_name = (TextInputEditText) findViewById(R.id.mother_name);
        personal_street = (TextInputEditText) findViewById(R.id.personal_street);
        personal_house_no = (TextInputEditText) findViewById(R.id.personal_house_no);
        nationality = (AutoCompleteTextView) findViewById(R.id.nationality);
        eritrean_id = (TextInputEditText) findViewById(R.id.eritrean_id);
        passport_no = (TextInputEditText) findViewById(R.id.passport_no);
        residence_id = (TextInputEditText) findViewById(R.id.residence_id);
        personal_phone_no = (TextInputEditText) findViewById(R.id.personal_phone_no);
        work_type = (AutoCompleteTextView) findViewById(R.id.work_type);
        name_of_work_owner = (TextInputEditText) findViewById(R.id.name_of_work_owner);
        work_house_no = (TextInputEditText) findViewById(R.id.work_house_no);
        work_name = (TextInputEditText) findViewById(R.id.work_name);
        trading_type = (TextInputEditText) findViewById(R.id.trading_type);
        tin_no = (TextInputEditText) findViewById(R.id.tin_no);
        asr_no = (TextInputEditText) findViewById(R.id.asr_no);
        asl_no = (TextInputEditText) findViewById(R.id.asl_no);
        license_no = (TextInputEditText) findViewById(R.id.license_no);
        bank_account_no = (TextInputEditText) findViewById(R.id.bank_account_no);
        amount_of_cash_on_hand = (TextInputEditText) findViewById(R.id.amount_of_cash_on_hand);
        if_other_specify = (TextInputEditText) findViewById(R.id.if_other_specify);
        source_of_cash = (AutoCompleteTextView) findViewById(R.id.source_of_cash);
        name_contact_person = (TextInputEditText) findViewById(R.id.name_contact_person);
        relation_contact_person = (TextInputEditText) findViewById(R.id.relation_contact_person);
        phone_contact_person = (TextInputEditText) findViewById(R.id.phone_contact_person);
        registrar_name = (TextInputEditText) findViewById(R.id.registrar_name);
        place_of_registration = (AutoCompleteTextView) findViewById(R.id.place_of_registration);
        name_of_receiver = (TextInputEditText) findViewById(R.id.name_of_receiver);
        date_of_registration = (TextInputEditText) findViewById(R.id.date_of_registration);
        name_of_controller = (TextInputEditText) findViewById(R.id.name_of_controller);

        male = (SoiraRadioButton) findViewById(R.id.male);
        female = (SoiraRadioButton) findViewById(R.id.female);

        bank_name = (Spinner) findViewById(R.id.bank_name);
        how_long_on_hand = (Spinner) findViewById(R.id.how_long_on_hand);

        is_owner = (CheckBox) findViewById(R.id.is_owner);
        consumption = (CheckBox) findViewById(R.id.consumption);
        emergency = (CheckBox) findViewById(R.id.emergency);
        trading = (CheckBox) findViewById(R.id.trading);
        house_rent = (CheckBox) findViewById(R.id.house_rent);
        other = (CheckBox) findViewById(R.id.other);
        permanent_phone_no = (CheckBox) findViewById(R.id.permanent_phone_no);

        texts.add(full_name);
        texts.add(male);
        texts.add(birth_year);
        texts.add(mother_name);
        texts.add(personal_zoba);
        texts.add(personal_sub);
        texts.add(personal_street);
        texts.add(personal_house_no);
        texts.add(nationality);
        texts.add(eritrean_id);
        texts.add(passport_no);
        texts.add(residence_id);
        texts.add(personal_phone_no);
        texts.add(work_type);
        texts.add(is_owner);
        texts.add(name_of_work_owner);
        texts.add(work_zoba);
        texts.add(work_sub);
        texts.add(work_house_no);
        texts.add(work_name);
        texts.add(trading_type);
        texts.add(tin_no);
        texts.add(asr_no);
        texts.add(asl_no);
        texts.add(license_no);
        texts.add(bank_account_no);
        texts.add(bank_name);
        texts.add(bank_division);
        texts.add(amount_of_cash_on_hand);
        texts.add(consumption);
        texts.add(if_other_specify);
        texts.add(source_of_cash);
        texts.add(how_long_on_hand);
        texts.add(name_contact_person);
        texts.add(relation_contact_person);
        texts.add(phone_contact_person);
        texts.add(permanent_phone_no);
        texts.add(registrar_name);
        texts.add(place_of_registration);
        texts.add(name_of_receiver);
        texts.add(date_of_registration);
        texts.add(name_of_controller);

    }

    private void addNewRow() {
        View row = inflater.inflate(R.layout.row_bank, null);
        containerLayout.addView(row);
        int count = containerLayout.getChildCount();
        int i = count - 1;
        row = containerLayout.getChildAt(i);
        TextView bank_number = (TextView) row.findViewById(R.id.bank_number);
        Spinner bank_name = (Spinner) row.findViewById(R.id.bank_name);
        AutoCompleteTextView bank_division = (AutoCompleteTextView) row.findViewById(R.id.bank_division);

        if (bank_number == null || bank_name == null || bank_division == null) {
            bank_number = (TextView) ((ViewGroup) row).getChildAt(0);
            bank_name = (Spinner) ((ViewGroup) row).getChildAt(3);
            bank_division = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(4);
        }
        bank_number.setText("4." + String.valueOf(i + 2) + ": Bank Name #" + String.valueOf(i + 2));

        bank_name.setAdapter(spinner_adapter);
        bank_division.setAdapter(adapter);
    }

    private void addSourceRow() {
        View row = inflater.inflate(R.layout.row_source, null);
        containerSource.addView(row);
        int count = containerSource.getChildCount();
        int i = count - 1;
        row = containerSource.getChildAt(i);
        AutoCompleteTextView source_of_cash = (AutoCompleteTextView) row.findViewById(R.id.source_of_cash_row);
        ImageView clear = (ImageView) row.findViewById(R.id.clean_source_row);

        if (source_of_cash == null) {
            source_of_cash = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(0);
            clear = (ImageView) ((ViewGroup) row).getChildAt(1);
        }
        source_of_cash.setHint("Source of cash held #" + String.valueOf(i + 2));
        final AutoCompleteTextView finalSource_of_cash = source_of_cash;
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finalSource_of_cash.setText("");
            }
        });
        finalSource_of_cash.setAdapter(source_adapter);

    }

    private void addWorkRow() {
        View row = inflater.inflate(R.layout.row_work, null);
        containerWork.addView(row);
        int count = containerWork.getChildCount();
        int i = count - 1;
        row = containerWork.getChildAt(i);

        TextView id = (TextView) row.findViewById(R.id.row_id);

        if (id == null) {
            id = (TextView) ((ViewGroup) row).getChildAt(0);
        }
        id.setText("3.1: Work Name [optional] #" + String.valueOf(i + 2));

    }

    private String[] fetchBanks() {
        int count = containerLayout.getChildCount();

        String DATA = "";

        for (int i = 0; i < count; i++) {
            View row = containerLayout.getChildAt(i);
            TextView bank_number = (TextView) row.findViewById(R.id.bank_number);
            EditText bank_code = (EditText) row.findViewById(R.id.bank_code);
            Spinner bank_name = (Spinner) row.findViewById(R.id.spinner);
            AutoCompleteTextView bank_division = (AutoCompleteTextView) row.findViewById(R.id.bank_division);

            if (bank_number == null || bank_code == null || bank_name == null || bank_division == null) {
                bank_number = (TextView) ((ViewGroup) row).getChildAt(0);
                bank_code = (EditText) ((ViewGroup) row).getChildAt(1);
                bank_name = (Spinner) ((ViewGroup) row).getChildAt(3);
                bank_division = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(4);

            }

            String selected_number = bank_number.getText().toString();
            String selected_code = bank_code.getText().toString();
            String selected_name = bank_name.getSelectedItem().toString();
            String selected_division = bank_division.getText().toString();

            if (
                    selected_code.isEmpty() ||
                            selected_division.isEmpty()

                    ) {
                continue;
            }

//            DATA += "ቁ. ሕሳብ ባንክ: "+selected_code+" # ስም ባንክ: "+selected_name+" # ጨንፈር: "+selected_division+"\n";
            DATA += selected_code + " # " + selected_name + " # " + selected_division + "\n";

        }
        if (DATA.endsWith("\n")) {
            DATA = DATA.substring(0, DATA.length() - 1);
        }

        return DATA.isEmpty() ? null : DATA.split("\n");
    }

    private String[] fetchSources() {
        int count = containerSource.getChildCount();

        String DATA = "";
        ArrayList<String> already = new ArrayList<>();
        String al = source_of_cash.getText().toString();
        if (!al.isEmpty()) {
            already.add(al);
        }
        for (int i = 0; i < count; i++) {
            View row = containerSource.getChildAt(i);
            AutoCompleteTextView source = (AutoCompleteTextView) row.findViewById(R.id.source_of_cash_row);

            if (source == null) {
                source = (AutoCompleteTextView) ((ViewGroup) row).getChildAt(0);

            }

            String word = source.getText().toString();

            if (
                    word.isEmpty() || already.contains(word)
                    ) {
                continue;
            }
            already.add(word);
            DATA += word + "\n";

        }
        if (DATA.endsWith("\n")) {
            DATA = DATA.substring(0, DATA.length() - 1);
        }

        return DATA.isEmpty() ? null : DATA.split("\n");
    }

    private String[] fetchWorks() {
        int count = containerWork.getChildCount();

        String DATA = "";
        for (int i = 0; i < count; i++) {
            View row = containerWork.getChildAt(i);
            EditText work_name = (EditText) row.findViewById(R.id.work_name);
            EditText trading_type = (EditText) row.findViewById(R.id.trading_type);
            EditText tin_no = (EditText) row.findViewById(R.id.tin_no);
            EditText asr_no = (EditText) row.findViewById(R.id.asr_no);
            EditText asl_no = (EditText) row.findViewById(R.id.asl_no);
            EditText license_no = (EditText) row.findViewById(R.id.license_no);

            if (work_name == null) {
                work_name = (EditText) ((ViewGroup) row).getChildAt(1);
                trading_type = (EditText) ((ViewGroup) row).getChildAt(2);
                tin_no = (EditText) ((ViewGroup) row).getChildAt(3);
                asr_no = (EditText) ((ViewGroup) row).getChildAt(4);
                asl_no = (EditText) ((ViewGroup) row).getChildAt(5);
                license_no = (EditText) ((ViewGroup) row).getChildAt(6);
            }

            String name = work_name.getText().toString().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            String type = trading_type.getText().toString().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            String tin = tin_no.getText().toString().toUpperCase().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            String asr = asr_no.getText().toString().toUpperCase().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            String asl = asl_no.getText().toString().toUpperCase().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");
            String license = license_no.getText().toString().toUpperCase().replace("=", "_").replace(",", "").
                    replace("#", "_").replace("@", "_").replace("’", "_").replace("”", "_").replace("\"", "_").replace("?", "_");

            if (
                    name.isEmpty()
                    ) {
                continue;
            }
            DATA += name + " # " + type + " # " + tin + " # " + asr + " # " + asl + " # " + license + "\n";

        }
        if (DATA.endsWith("\n")) {
            DATA = DATA.substring(0, DATA.length() - 1);
        }

        return DATA.isEmpty() ? null : DATA.split("\n");
    }

    private void initialize_workers() {
        ArrayAdapter<CharSequence> spinner_adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_data, android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter<CharSequence> duration_adapter = ArrayAdapter.createFromResource(this,
                R.array.duration, android.R.layout.simple_spinner_dropdown_item);

        bank_name.setAdapter(spinner_adapter);
        how_long_on_hand.setAdapter(duration_adapter);

        registrar_name.setText(sharedPreferences.getString("two", ""));
        place_of_registration.setText(sharedPreferences.getString("three", ""));
        name_of_receiver.setText(sharedPreferences.getString("four", ""));

        date_of_registration.setText(DateFormat.format("dd/MM/yyyy",
                new Date()));

        name_of_controller.setText(sharedPreferences.getString("six", ""));

        nationality.setText("Eritrean");

    }
}
